/* vim: set sw=8: -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef _GNM_SESSION_H_
# define _GNM_SESSION_H_

#include "gnumeric.h"

G_BEGIN_DECLS

void gnm_session_init (char const *argv0);
/* gboolean gnm_session_is_restored (void); */
/* gboolean gnm_session_load (void); */

G_END_DECLS

#endif /* _GNM_SESSION_H_ */
